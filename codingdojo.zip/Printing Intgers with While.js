

    var i = 2000;
    while(i < 5281){
        console.log(i);
        i++
    }
    

