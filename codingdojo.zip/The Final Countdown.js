

function countDown(x){
var param1 = x[0];
var param2 = x[1];
var param3 = x[2];
var param4 = x[3];
var blank = [];
var i = 0;

    while(param1 <= param3){

        if(param1 >= param2){
            if(param1 !== param4){
                
                var result = console.log(param1);
            }else{
                blank.push(param1);
            }
       
        }
        param1 = param1 + x[0];
    }
    return result;

}

countDown([3,5,17,9]);

