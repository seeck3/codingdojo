

function countDown(x){
var param1 = x[0];
var param2 = x[1];
var param3 = x[2];
var param4 = x[3];
var blank = [];
var i = param1;

    while(i <= param3){

        if(i >= param2){
            if( i !== param4){
                
                console.log(i);
            }else{
                blank.push(i);
            }
            i = i + i;
        }
    }
    return x;

}

countDown([3,5,17,9]);
