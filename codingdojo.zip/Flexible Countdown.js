

function countDown(x){
    var sum = 0;
    
    var lowNum = x[0];
    var highNum = x[1];
    var mult = x[2];
    for(var i = 0; i <= highNum; i = i + mult){

        if(i >= lowNum){
            sum = i;
            var result = console.log(sum);
        }
        
    }
    
    return result;

}

countDown([2,9,3]);
