var user = [{name: "Michael", age: 37}, {name: "John", age: 30}, {name: "David", age: 27}];

    for(var i = 0; i < user.length; i++){

        console.log(user[i].name," - ", user[i].age);
    }


console.log(user[1].age);
console.log(user[0].name);


