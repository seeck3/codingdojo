function sumOdd(){
    var sum = 0;
    
    for(var i = 0; i <= 5000; i++){
        
        if(i % 2 == 1){
        sum += i;
        
      }
   
    }
    console.log(sum);
    
}

sumOdd();