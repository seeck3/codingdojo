function greaterThan(x,Y){
    var num = 0;

    for(var i = 0; i < x.length; i++){

        if(x[i] > Y){
            num = num + 1;
        }
    }
    return num;
}

greaterThan([1, 3, 5, 7],3);