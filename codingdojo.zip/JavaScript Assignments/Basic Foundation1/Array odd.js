function arrayOdd(x){
    var arr = [];

    for(var i = 0; i <= x; i++){
        if(i % 2 == 1){
            arr.push(i);
        }
    }
    return arr;
}

arrayOdd(50);