function findMax(x){
    var max = 0;
    for(var i = 0; i < x.length; i++)

    if(x[i] > x[0]){
        x[0] = x[i];
        max = x[0];
    }
    
    return max;
}

findMax([-3,3,5,7]);