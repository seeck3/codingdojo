function squares(x){
    
    for(var i = 0; i < x.length; i++){

        x[i] = x[i] * x[i];
    }

    return x;
}

squares([1,5,10,-2]);