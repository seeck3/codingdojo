function findAvg(x){
    var avg = 0;
    var sum = 0;
    for(var i = 0; i < x.length; i++){
        sum += x[i];
    }
    avg = sum / x.length;
    return avg;
}

findAvg([1,3,5,7,20]);