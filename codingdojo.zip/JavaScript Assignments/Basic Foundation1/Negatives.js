function negatives(x){

    for(var i = 0; i < x.length; i++){
        if(x[i] < 0){
            x[i] = 0;
        }
    }
    return x;
}

negatives([1,5,10,-2]);
