function numToStr(x){
    var str = "Dojo";

    for(var i = 0; i < x.length; i++){

        if(x[i] < 0){
            x[i] = str;
        }
    }
    return x;
}

numToStr([-1,-3,2]);