function swapValues(x){
    var temp = 0;

    temp = x[0];
    x[0] = x[x.length - 1];
    x[x.length - 1] = temp;

    return x;
}

swapValues([1,5,10,-2]);