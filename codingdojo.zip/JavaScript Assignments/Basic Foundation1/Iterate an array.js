function iterateArray(x){
    var sum = 0;

    for(var i = 0; i < x.length; i++){

        sum = sum + x[i];
    }
    return sum;
}

iterateArray([1,2,5]);