function getEven(){

    for(var i = 0; i <= 1000; i++){

        if(i % 2 == 0){
            console.log(i);
        }
    }
}

getEven();