function maxMinAvg(x){
    var max = 0;
    var min = 0;
    var sum = 0;
    var avg = 0;
    var arr = [];

    for(var i = 0; i < x.length; i++){

        if(x[i] >= x[0]){
            max = x[i];
        }
        
        if(x[i] <= x[0]){
            min = x[i];
        }
       
        sum = sum + x[i];
      
        
    }
    
    avg = sum / x.length;
    arr = [max, min, avg];
    
    return arr;

}

maxMinAvg([1,5,10,-2]);