function fibonacci(x){

    if(x < 2){
        return x;
    }

    var num = 1;
    var num2 = 1;
    for(var i = 2; i < x; i++){
        var temp = num;
        num += num2;
        num2 = temp;
    }
    return num;
}
  

fibonacci(7);