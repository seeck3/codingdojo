function secondLargest(x){

    var largeNum1 = 0;
	var largeNum2 = 0;
	
	for(var i = 0; i < x.length; i++){
		if(largeNum1 < x[i]){
			largeNum2 = largeNum1;
			largeNum1 = x[i];			
		}else if(largeNum2 < x[i]){
			largeNum2 = x[i];
		}
	}
	
	return largeNum2;
	


}

secondLargest([42,1,4,3.14,7]);