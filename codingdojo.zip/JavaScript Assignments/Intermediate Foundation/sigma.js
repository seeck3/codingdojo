function sigma(num){
    var sum = 0;

    for(var i = 0; i <= num; i++){

        sum = sum + i;
    }
    return sum;
}

sigma(3);