function doubleTrouble(x){

    for(var i = 0; i < x.length; i = i + 2){

        if(i == 0){
        x.splice((i + 1), 0, x[i]);
     }else{
        x.splice((i + 1), 0, x[i]);
    }
     
    }
    return x;
}

doubleTrouble([4, "Ulysses", 42, false]);