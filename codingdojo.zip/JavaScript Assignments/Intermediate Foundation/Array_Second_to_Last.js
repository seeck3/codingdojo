function secondLast(x){

    if(x.length < x[2]){
        return null;
    }
    
    return console.log(x[x.length - 2]);
}

secondLast([42, true, 4, "Liam", 7]);