function nthToLast(x,y){

    if(x[x.length - 1] < x[y]){

        return null;
    }

    return console.log(x[x.length - y]);
}

nthToLast([5,2,3,6,4,9,7],3);