function negativeArray(x){

    for(var i = 0; i <x.length; i++){

        if(x[i] > 0){
            x[i] = x[i] - x[i] - x[i];
        }
    }
    console.log(x);
}

negativeArray([1,-3,5]);