function countPositives(x){
    var arr = [];
    

    for(var i = 0; i < x.length; i++){
        if(x[i] > 0){
            arr.push(x[i]);
        }
        var count = arr.length;

    }
    x[x.length - 1] = count;
    return x;

}

countPositives([-1,1,1,1]);