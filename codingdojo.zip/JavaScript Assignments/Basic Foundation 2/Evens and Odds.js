function evenOdd(x){
    var evenstr = "Even more so!";
    var oddstr = "That's odd!";

    for(var i = 0; i < x.length; i++){
        
        if(x[i] % 2 === 0 && x[i] !== x[x.length - 1]){
            var even1 = x[i + 1] % 2 === 0;
            var even2 = x[i + 2] % 2 === 0;
            if(even1 && even2 === true){
                console.log(evenstr);    
            }
            
        }
        if(x[i] % 2 === 1 && x[i] !== x[x.length - 1]){
            var odd1 = x[i + 1] % 2 === 1;
            var odd2 = x[i + 2] % 2 === 1;
            if(odd1 && odd2 === true){
                console.log(oddstr);    
            }
            
        }
    
  
    
    }
    
}
evenOdd([4,2,6,5,7,9]);
