function prevLength(x){
   
    for(var i = x.length - 1; i > 0; i--){
     
        x[i] = x[i - 1].length;
    
    }

    return x;

}

prevLength(["hello", "dojo", "awesome"]);