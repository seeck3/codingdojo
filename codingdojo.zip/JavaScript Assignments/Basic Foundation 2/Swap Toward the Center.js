function swapCenter(x){

    var temp = x[0];
    var temp3 = x[0 + 2];

    x[0] = x[x.length - 1];
    x[0 + 2] = x[x.length - 3];
    x[x.length - 1] = temp;
    x[x.length - 3] = temp3;

    return x;
}

console.log(swapCenter([1,2,3,4,5,6]));
console.log(swapCenter([true, 42, "Ada", 2, "pizza"]));