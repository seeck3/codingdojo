function bigSize(x){
    var arr = [];
    var str = "big";

    for(var i = 0; i < x.length; i++){

        if(x[i] > 0){
            x[i] = str;
            
        }
        arr.push(x[i]);
    }
    return arr;
}

bigSize([-1,3,5,-5]);