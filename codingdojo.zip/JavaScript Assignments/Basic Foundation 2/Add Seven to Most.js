function addSeven(x){
    var arr = [];

    for(var i = 0; i < x.length; i++){

        if(x[i] !== x[0]){
            arr.push(x[i] + 7);
        }
    }
    return arr;
}

addSeven([0,1,2,3,4,5,6,7,8,9,10]);