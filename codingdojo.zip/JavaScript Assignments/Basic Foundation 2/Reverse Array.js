function reverseArray(x){

    x.reverse();

    console.log(x);

}

reverseArray([3,1,6,4,2]);