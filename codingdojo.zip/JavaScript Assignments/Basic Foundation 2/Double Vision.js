function doubleVision(x){

    for(var i = 0; i < x.length; i++){

        x[i] = x[i] + x[i];
    }
    return x;
}

doubleVision([1,2,3]);