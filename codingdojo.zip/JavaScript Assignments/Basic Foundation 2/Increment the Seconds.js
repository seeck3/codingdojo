function increment(arr){
    
    for(var i = 0; i < arr.length; i++){

        if(i % 2 === 1){
            console.log(arr[i] + 1);

        }else{
        console.log(arr[i]);
     }
    }

    return arr;

}

increment([2,2,2,2,2,2,2,2,2,2]);