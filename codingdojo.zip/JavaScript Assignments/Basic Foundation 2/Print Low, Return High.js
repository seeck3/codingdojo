function printReturn(x){

    var lowArr = [];
    var highArr = [];
    var low = 0;
    var high = 0;

    for(var i = 0; i < x.length; i++){

        if(x[i] >= x[0]){
            x[0] = x[i];
            high = x[0];
        }
       
        if(x[i] <= x[0]){
            x[0] = x[i];
            low = x[0];
        }
     
    }

    console.log(low);
    return high;
}

printReturn([2,3,6,5,4,1]);