function scaleArray(arr,num){

    for(var i = 0; i < arr.length; i++)

    arr[i] = arr[i] * num;

    return arr;
}

scaleArray([1,2,3],3);