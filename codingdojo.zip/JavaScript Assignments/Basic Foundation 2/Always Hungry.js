function alwaysHungry(x){
    var food = "yummy";
    var nofood = "I'm hungry";

    for(var i = 0; i < x.length; i++){
        
        if(x.includes("food") !== true){
            console.log(nofood);
            break;
        }else if(x[i] == "food"){
        console.log(food);
        }
        
        
    }
    return x;
}

alwaysHungry(["food","food",1,4,2,"food"]);