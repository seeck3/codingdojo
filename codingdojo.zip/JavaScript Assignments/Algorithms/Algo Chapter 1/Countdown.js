function countDown(x){
    var arr = [];

    for(var i = x; i >= 0; i--){

        arr.push(i);
    }
    console.log(arr.length);
    return arr;
}

countDown(10);