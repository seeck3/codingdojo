function greaterThanSecond(x){
    var arr = [];
    for(var i = 0; i < x.length; i++)

        if(x.length < 2){
            console.log(null);
        }else if(x[i] > x[1]){
            arr.push(x[i]);
        }
        console.log(arr);

        return arr.length;
}

greaterThanSecond([1,3,5,7,9,13]);