

function dojoWay(){

    for(var i = 0; i <= 100; i++){

        if(i % 10 === 0){
            console.log("Dojo " + i) // I added i, to check if it is working properly
        }else if(i % 5 === 0){
            console.log("Coding " + i) // i added i, to check if it is working properly
        }
    }
    return;

}

dojoWay();

