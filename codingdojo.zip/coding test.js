function odd(arr) {
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] % 2 === 0 && arr[i] !== arr[arr.length - 1]) {
                var nextNum = arr[i + 1] % 2 === 0
                var nextNum2 = arr[i + 2] % 2 === 0
                if (nextNum && nextNum2 === true) {
                console.log("thats even")
                }
            }
        if (arr[i] % 2 === 1 && arr[i] !== arr[arr.length - 1]) {
            var nextOddNum = arr[i + 1] % 2 === 1
            var nextOddNum2 = arr[i + 2] % 2 === 1
            if (nextOddNum && nextOddNum2 === true) {
            console.log("thats odd")
                }
            }
        }
    }