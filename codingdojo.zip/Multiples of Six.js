

var i = 0
while(i < 60001){
    if(i % 6 === 0){
        console.log(i);
    }
    i++;
}
