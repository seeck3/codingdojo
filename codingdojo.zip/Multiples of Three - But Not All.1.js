

function multiThree(){
    var arr = [];
    
    for(var i = -300; i < 0; i + 3){
        if(i == -6 || i == -3){
            
        }else
        arr.push(i);
    }
    return arr;

}

multiThree(); 