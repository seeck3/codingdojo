

function puzzle(){
    var num = [];
    var sum = 0
    for(var i = 1; i <= 100; i * i){

        sum = (i * i) + 1;
        num.push(i);
    }

    return num;

}