

function print(){

    var num = []

    for(var i = -52; i < 1067; i++){
        num.push(i);
    }
    return num;
}

print();