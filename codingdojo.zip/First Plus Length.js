function firstLength(x){

    return x[0], x.length; 
   
}

console.log(firstLength(["what?"]));
console.log(firstLength([false]));