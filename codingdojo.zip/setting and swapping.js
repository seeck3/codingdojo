

var myNumber = 42;
var myName = Marco;

myNumber = myName;
myName = ViceVersa;