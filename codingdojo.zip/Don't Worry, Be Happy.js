

function beCheerful(){
    var cheer = "good morning";

    for(var i = 1; i < 99; i++){

        console.log(cheer + i);
    }
    return;
}

beCheerful();