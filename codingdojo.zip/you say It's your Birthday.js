
var Birthday = (4, 19);
function yourBirthday(Birthday){
    
    if(Birthday == (4, 19)){

        console.log("How did you know?")
    }else{
        console.log("Just another day...")
    }

}

yourBirthday(Birthday);