

function doorLock(incoming){

    if(incoming == "Marco"){

        console.log("Welcome, Master Marco Seo");
    }else{
        console.log("I don't know who you are.. I will find you, and I will kill you");
    }
}

doorLock("Marco");