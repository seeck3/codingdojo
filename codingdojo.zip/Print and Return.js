function printReturn(x){

    console.log(x[0]);

    return x[1];


}

printReturn([1,2]);